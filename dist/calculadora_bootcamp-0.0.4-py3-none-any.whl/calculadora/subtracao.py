def subtracao(num1, num2):
    resultado = num1 - num2
    return resultado
