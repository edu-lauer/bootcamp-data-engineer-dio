# calculadora_bootcamp

Description. 
The calculadora-bootcamp is first my package created used to:
	- Calcular multiplicacao de 2 numeros
	- Calcular soma de 2 numeros
	- Calcular subtracao de 2 numeros

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install calculadora-python

```bash
pip install calculadora_bootcamp
```

## Usage

```python
from calculadora_bootcamp import multiplicacao
import calculadora_bootcamp.multiplicacao

from calculadora_bootcamp import soma
import calculadora_bootcamp.soma

from calculadora_bootcamp import subtracao
import calculadora_bootcamp.subtracao
```

## Author
Eduardo

## License
[MIT](https://choosealicense.com/licenses/mit/)